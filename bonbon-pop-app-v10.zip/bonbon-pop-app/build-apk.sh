#!/usr/bin/env bash
# Builds bonbon-pop.apk on macOS or Linux.
# Needs: Node.js 22+, JDK 21, and the Android SDK (installed by Android Studio) with ANDROID_HOME set.
set -e
cd "$(dirname "$0")"

command -v node >/dev/null || { echo "Install Node.js 22 or newer first: https://nodejs.org"; exit 1; }
command -v java >/dev/null || { echo "Install JDK 21 first."; exit 1; }
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo "Set ANDROID_HOME to your Android SDK folder. Android Studio installs one for you."
  exit 1
fi

npm install @capacitor/core @capacitor/cli @capacitor/android
npm install -D @capacitor/assets

[ -d android ] || npx cap add android

MANIFEST=android/app/src/main/AndroidManifest.xml
grep -q screenOrientation "$MANIFEST" || perl -0pi -e 's/<activity/<activity android:screenOrientation="portrait"/' "$MANIFEST"

npx capacitor-assets generate --android
npx cap sync android
(cd android && ./gradlew assembleDebug)

cp android/app/build/outputs/apk/debug/app-debug.apk bonbon-pop.apk
echo
echo "Done. Your APK is here: $(pwd)/bonbon-pop.apk"
