@echo off
rem Builds bonbon-pop.apk on Windows.
rem Needs: Node.js 22+, JDK 21, and the Android SDK (installed by Android Studio) with ANDROID_HOME set.
cd /d "%~dp0"

where node >nul 2>nul || (echo Install Node.js 22 or newer first: https://nodejs.org & exit /b 1)
where java >nul 2>nul || (echo Install JDK 21 first. & exit /b 1)
if "%ANDROID_HOME%%ANDROID_SDK_ROOT%"=="" (echo Set ANDROID_HOME to your Android SDK folder. Android Studio installs one for you. & exit /b 1)

call npm install @capacitor/core @capacitor/cli @capacitor/android || exit /b 1
call npm install -D @capacitor/assets || exit /b 1

if not exist android call npx cap add android || exit /b 1

powershell -NoProfile -Command "$f='android\app\src\main\AndroidManifest.xml'; $s=Get-Content $f -Raw; if($s -notmatch 'screenOrientation'){ $q=[char]34; $r=[regex]'<activity'; $s=$r.Replace($s,('<activity android:screenOrientation='+$q+'portrait'+$q),1); Set-Content $f $s -NoNewline }"

call npx capacitor-assets generate --android || exit /b 1
call npx cap sync android || exit /b 1
pushd android
call gradlew.bat assembleDebug || (popd & exit /b 1)
popd

copy /y android\app\build\outputs\apk\debug\app-debug.apk bonbon-pop.apk
echo.
echo Done. Your APK is here: %cd%\bonbon-pop.apk
