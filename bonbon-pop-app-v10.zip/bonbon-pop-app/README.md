# Bonbon Pop: app package

The whole game is one file, `www/index.html`. It works offline and saves progress on the device.

```
bonbon-pop-app/
  www/                 the game (index.html, manifest, service worker, icons)
  assets/              1024px icon and 2732px splash for the Android build
  capacitor.config.json
  package.json
```

## Get the APK

An APK is the file you install on an Android phone. It was not built inside this package because that needs the Android SDK. Use one of these two ways.

**Way 1: build it online with GitHub (no Android Studio, nothing to install)**

1. Create a new repository on GitHub and upload everything in this folder. Check that the hidden `.github` folder came with it; some file managers skip hidden folders. Pushing with `git` always includes it.
2. Open the repository's Actions tab, choose "Build Android APK", and press Run workflow.
3. Wait about five minutes, open the finished run, and download `bonbon-pop-apk` from Artifacts. Unzip it to get `app-debug.apk`.

**Way 2: build it on your computer with one command**

Install Node.js 22 or newer, JDK 21 and Android Studio (it installs the Android SDK), and set `ANDROID_HOME` to the SDK folder. Then run `./build-apk.sh` on macOS or Linux, or double-click `build-apk.bat` on Windows. The finished `bonbon-pop.apk` appears in this folder.

**Install on your phone:** send the APK to the phone, open it, and allow "Install unknown apps" for the app you opened it from when Android asks. This is a debug-signed APK, which is fine for your own phone and for sharing with friends. A store upload needs a signed release build (see Option B below).

## Option A: install it as a web app (fastest, no build)

1. Upload the contents of `www/` to any HTTPS static host (Netlify Drop, Cloudflare Pages, GitHub Pages, your own server).
2. Open the address on your phone.
3. Android Chrome: menu, then "Install app" (or "Add to Home screen"). iPhone Safari: Share, then "Add to Home Screen".

It opens full screen with its own icon, and works offline after the first visit.

## Option B: build a real Android app (APK or AAB)

You need Node.js and Android Studio on your computer.

```
npm install @capacitor/core @capacitor/cli @capacitor/android
npm install -D @capacitor/assets
npx cap add android
npm run assets
npm run sync
npm run android
```

Android Studio opens the project. Then use Build, Build Bundle(s) / APK(s), Build APK(s) for a file you can install directly, or Generate Signed Bundle for a store upload.

Before you publish, change `appId` in `capacitor.config.json` from `com.example.bonbonpop` to an id you own, for example `com.yourname.bonbonpop`. Do this before running `npx cap add android`.

To lock the game to portrait, add `android:screenOrientation="portrait"` to the `<activity>` tag in `android/app/src/main/AndroidManifest.xml`, then run `npm run sync`.

## Option C: iOS

On a Mac with Xcode: `npm install @capacitor/ios`, `npx cap add ios`, `npx cap open ios`. An Apple developer account is needed to put it on a device for long or to publish.

## Updating the game

Replace `www/index.html`, bump `CACHE` in `www/sw.js` (for example to `bonbon-pop-v2`), then upload again (web) or run `npm run sync` (Android).

## Fonts

The game asks Google Fonts for its two typefaces. Offline, or inside the Android app without a connection, it falls back to the phone's system fonts and still plays normally. To bundle the fonts, download Fredoka and DM Sans, put the files in `www/fonts/`, and replace the `<link>` in `index.html` with `@font-face` rules.
